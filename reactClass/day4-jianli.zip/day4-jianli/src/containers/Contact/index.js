import React from 'react';

export default class Contact extends React.Component{
    render(){
        return(
            <div>
                <h1>Contact联系我们</h1>
            </div>
        )
    }
}