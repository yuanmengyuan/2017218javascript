import React from 'react';

export default class Skill extends React.Component{
    render(){
        return(
            <div>
                <h1>Skill工作技能</h1>
            </div>
        )
    }
}